import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Navbar from '../src/components/Navbar';
import BlogPostList from '../src/components/BlogPostList';
import CreateBlog from '../src/components/CreateBlog';
import BlogPostEdit from '../src/components/BlogPostEdit'; 
import BlogPostDetail from '../src/components/BlogPostDetail';

function App() {
  return (
    <Router>
      <div>
        <Navbar />
        <div className="container mt-4">
          <Switch>
            <Route exact path="/" component={BlogPostList} />
            <Route path="/create" component={CreateBlog} />
            <Route exact path="/edit/:id" component={BlogPostEdit} /> 
            <Route path="/blog/:id" component={BlogPostDetail} />
          </Switch>
        </div>
      </div>
    </Router>
  );
}

export default App;
