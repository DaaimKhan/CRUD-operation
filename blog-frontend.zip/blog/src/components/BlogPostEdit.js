import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useHistory, useParams } from 'react-router-dom';

function BlogPostEdit() {
  const [formData, setFormData] = useState({
    title: '',
    content: '',
    author: '',
    publication_date: '',
  });

  const history = useHistory();
  const { id } = useParams();

useEffect(() => {
  axios.get(`http://127.0.0.1:8000/api/blog-posts/${id}`)
    .then((response) => {
      if (response.data) {
        const { title, content, author, publication_date } = response.data;
        setFormData({ title, content, author, publication_date });
      } else {
        console.error('Invalid response data:', response.data);
      }
    })
    .catch((error) => {
      console.error(error);
    });
}, [id]);

  

  const handleSubmit = (e) => {
    e.preventDefault();

    axios.put(`http://127.0.0.1:8000/api/blog-posts/${id}`, formData)
      .then((response) => {
        // Redirect to the blog post detail page after editing
        history.push('/');
      })
      .catch((error) => {
        console.error(error);
      });
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  return (
    <div className="container mt-4">
      <h2>Edit Blog Post</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>Title</label>
          <input
            type="text"
            name="title"
            className="form-control"
            value={formData.title}
            onChange={handleInputChange}
            required
          />
        </div>
        <div className="form-group">
          <label>Content</label>
          <textarea
            name="content"
            className="form-control"
            value={formData.content}
            onChange={handleInputChange}
            required
          />
        </div>
        <div className="form-group">
          <label>Author</label>
          <input
            type="text"
            name="author"
            className="form-control"
            value={formData.author}
            onChange={handleInputChange}
            required
          />
        </div>
        <div className="form-group">
          <label>Publication Date</label>
          <input
            type="date"
            name="publication_date"
            className="form-control"
            value={formData.publication_date}
            onChange={handleInputChange}
            required
          />
        </div>
        <button type="submit" className="btn btn-primary">Update</button>
      </form>
    </div>
  );
}

export default BlogPostEdit;
