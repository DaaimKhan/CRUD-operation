import React, { useState } from 'react';
import axios from 'axios';
import { useHistory } from 'react-router-dom';

function CreateBlog() {
  const [formData, setFormData] = useState({
    title: '',
    content: '',
    author: '',
    publication_date: '',
  });

  const history = useHistory();

  const handleSubmit = (e) => {
    e.preventDefault();

    // Send a POST request to create a new blog post
    axios.post('http://127.0.0.1:8000/api/blog-posts/', formData)
      .then((response) => {
        console.log('Blog post created:', response.data);
        // Redirect to the list of blog posts after creation
        history.push('/');
      })
      .catch((error) => {
        console.error('Error creating blog post:', error);
      });
  };

  return (
    <div>
      <h2>Create New Blog</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="title">Title</label>
          <input
            type="text"
            className="form-control"
            id="title"
            name="title"
            value={formData.title}
            onChange={(e) => setFormData({ ...formData, title: e.target.value })}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="content">Content</label>
          <textarea
            className="form-control"
            id="content"
            name="content"
            rows="4"
            value={formData.content}
            onChange={(e) => setFormData({ ...formData, content: e.target.value })}
            required
          ></textarea>
        </div>
        <div className="form-group">
          <label htmlFor="author">Author</label>
          <input
            type="text"
            className="form-control"
            id="author"
            name="author"
            value={formData.author}
            onChange={(e) => setFormData({ ...formData, author: e.target.value })}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="publication_date">Publication Date</label>
          <input
            type="date"
            className="form-control"
            id="publication_date"
            name="publication_date"
            value={formData.publication_date}
            onChange={(e) => setFormData({ ...formData, publication_date: e.target.value })}
            required
          />
        </div>
        <button type="submit" className="btn btn-primary">Create Blog</button>
      </form>
    </div>
  );
}

export default CreateBlog;
