import React, { useState, useEffect } from 'react';
import axios from 'axios';

function BlogPostDetail({ match }) {
  const [blogPost, setBlogPost] = useState({});

  useEffect(() => {
    axios.get(`http://127.0.0.1:8000/api/blog-posts/${match.params.id}`)
      .then((response) => {
        setBlogPost(response.data);
      })
      .catch((error) => {
        console.error(error);
      });
  }, [match.params.id]);

  return (
    <div className="container mt-4">
    
      <div className="card">
        <div className='card-header'>
            <h2>{blogPost.title}</h2>
        </div>
        <div className="card-body">
            <div className="mt-4">
                 <p>{blogPost.content}</p>
            </div>
        </div>
        <div className='card-footer'>
         <p className="card-text">Author: {blogPost.author}</p>
          <p className="card-text">Publication Date: {blogPost.publication_date}</p>
        </div>
      </div>
      
    </div>
  );
}

export default BlogPostDetail;
