import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

function BlogPostList() {
  const [blogPosts, setBlogPosts] = useState([]);

  useEffect(() => {
    axios.get('http://127.0.0.1:8000/api/blog-posts/')
      .then((response) => {
        // Access the array of blog posts using response.data.data
        setBlogPosts(response.data.data);
      })
      .catch((error) => {
        console.error(error);
      });
  }, []);

  const handleDelete = (postId) => {
    // Send a DELETE request to your API to delete the blog post
    axios.delete(`http://127.0.0.1:8000/api/blog-posts/${postId}`)
      .then((response) => {
        // Remove the deleted blog post from the state
        setBlogPosts(blogPosts.filter(post => post.id !== postId));
      })
      .catch((error) => {
        console.error(error);
      });
  };

  return (
    <div className="container mt-4">
     
      <div className="list-group">
        {blogPosts.map((post) => (
          <div key={post.id} className="list-group-item">
            <Link to={`/blog/${post.id}`}>
              <h3>{post.title}</h3>
            </Link>
            <p className="mt-2">{post.content}</p>
            <p className="mb-0"><strong>Author:</strong> {post.author}</p>
            <p className="mb-0"><strong>Publication Date:</strong> {post.publication_date}</p>
           
            <div className="btn-group" role="group">
              <Link to={`/edit/${post.id}`} className="btn btn-secondary">Edit</Link>
              <button className="btn btn-danger" onClick={() => handleDelete(post.id)}>Delete</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default BlogPostList;
